package com.company.coursework.pizza.users;

public class Admin extends User {
    public Admin(String nickname, String login, String password) {
        super(nickname, login, password);
    }
}
